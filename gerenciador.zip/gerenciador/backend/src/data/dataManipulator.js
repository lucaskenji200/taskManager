const fs = require('fs');
const path = require('path');

const dataPath = './tasks.json'
console.log('Caminho do arquivo de dados:', dataPath); 

const readData = () => {
  try {
    const data = fs.readFileSync(dataPath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
};

const writeData = (data) => {
  try {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('Erro ao escrever no arquivo de dados:', error);
  }
};

module.exports = { readData, writeData };