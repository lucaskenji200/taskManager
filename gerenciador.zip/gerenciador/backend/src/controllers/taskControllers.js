const { readData, writeData } = require('../data/dataManipulator');

exports.createTask = (req, res) => {
  const tasks = readData();
  const { name, description, status } = req.body;

  if (!name || typeof name !== 'string' || name.trim() === '') {
    return res.status(400).json({ success: false, error: 'O campo "name" é obrigatório.' });
  }

  const newTask = {
    id: Date.now() + Math.floor(Math.random() * 1000),
    name: name.trim(),
    description: description?.trim() || '',
    status: status?.trim() || 'Não Iniciado',
    createdAt: new Date().toISOString(),
  };

  tasks.push(newTask);
  writeData(tasks);
  res.status(201).json({ success: true, data: newTask });
};

exports.getTasks = (req, res) => {
  const tasks = readData();
  const { status } = req.query;

  const filteredTasks = status
    ? tasks.filter(t => t.status.toLowerCase() === status.toLowerCase())
    : tasks;

  res.status(200).json({ success: true, count: filteredTasks.length, data: filteredTasks });
};

exports.updateTask = (req, res) => {
  const tasks = readData();
  const taskId = parseInt(req.params.id, 10);
  const taskIndex = tasks.findIndex(t => t.id === taskId);

  if (taskIndex === -1) {
    return res.status(404).json({ success: false, error: 'Tarefa não encontrada' });
  }

  const updatedFields = {};
  if (req.body.name) updatedFields.name = req.body.name.trim();
  if (req.body.description) updatedFields.description = req.body.description.trim();
  if (req.body.status) updatedFields.status = req.body.status.trim();

  tasks[taskIndex] = {
    ...tasks[taskIndex],
    ...updatedFields,
    updatedAt: new Date().toISOString(),
  };

  writeData(tasks);
  res.status(200).json({ success: true, data: tasks[taskIndex] });
};

exports.deleteTask = (req, res) => {
  let tasks = readData();
  const taskId = parseInt(req.params.id, 10);
  const taskToDelete = tasks.find(t => t.id === taskId);

  if (!taskToDelete) {
    return res.status(404).json({ success: false, error: 'Tarefa não encontrada' });
  }

  tasks = tasks.filter(t => t.id !== taskId);
  writeData(tasks);

  res.status(200).json({ success: true, data: taskToDelete });
};