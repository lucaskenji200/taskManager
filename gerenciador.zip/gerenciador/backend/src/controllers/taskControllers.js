const { readData, writeData } = require('../data/dataManipulator');

exports.createTask = (req, res) => {
  const tasks = readData();
  const newTask = {
    id: Date.now(), 
    ...req.body,
    status: req.body.status || 'Não Iniciado', 
  };
  tasks.push(newTask);
  writeData(tasks);
  res.status(201).json({ success: true, data: newTask });
};

exports.getTasks = (req, res) => {
  const tasks = readData();
  res.status(200).json({ success: true, count: tasks.length, data: tasks });
};

exports.updateTask = (req, res) => {
  const tasks = readData();
  const taskId = parseInt(req.params.id, 10);
  const taskIndex = tasks.findIndex(t => t.id === taskId);

  if (taskIndex === -1) {
    return res.status(404).json({ success: false, error: 'Tarefa não encontrada' });
  }

  tasks[taskIndex] = { ...tasks[taskIndex], ...req.body };
  writeData(tasks);
  
  res.status(200).json({ success: true, data: tasks[taskIndex] });
};

  exports.deleteTask = (req, res) => {
  let tasks = readData();
  const taskId = parseInt(req.params.id, 10);
  const initialLength = tasks.length;

  tasks = tasks.filter(t => t.id !== taskId);

  if (tasks.length === initialLength) {
    return res.status(404).json({ success: false, error: 'Tarefa não encontrada' });
  }

  writeData(tasks);
  res.status(200).json({ success: true, data: {} });
};