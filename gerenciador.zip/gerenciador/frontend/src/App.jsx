import React from 'react'
import MainPage from './components/MainPage'

const App = () => {
  return (
    <div>
      <MainPage/>
    </div>
  )
}

export default App;