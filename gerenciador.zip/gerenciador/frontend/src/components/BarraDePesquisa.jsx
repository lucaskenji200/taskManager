import React, { useState } from 'react';
import './BarraDePesquisa.css';
import FilterBox from './FilterBox';

const BarraDePesquisa = ({ onAddClick }) => {
  const [input, setInput] = useState("");
  
  const handleChange = (event) => {
    setInput(event.target.value);
  };
  const handleSubmit = (event) => {
    event.preventDefault();
  };

  return (
    <div>
      <div className='c2'>
        <div className='searchWrapper'>
          <form className='searchBar' onSubmit={handleSubmit}>
            <label className='searchLabel'>
              <input 
                className='searchInput' 
                placeholder='Digite a tarefa pendente' 
                value={input} 
                onChange={handleChange}
              />
            </label>
          </form>
          <button type="button" className='CRUDOptions' onClick={onAddClick}>
            +
          </button>
        </div>
      </div>
    </div>
  );
};

export default BarraDePesquisa;