import React from 'react';
import './BarraDePesquisa.css';
import FilterBox from './FilterBox';

const BarraDePesquisa = ({ onAddClick, searchTerm, onSearchChange, selectedStatus, onStatusChange }) => {
  
  const handleSubmit = (event) => {
    event.preventDefault();
  };

  return (
    <div>
      <div className='c2'>
        <div className='searchWrapper'>
          <form className='searchBar' onSubmit={handleSubmit}>
            <label className='searchLabel'>
              <input 
                className='searchInput' 
                placeholder='Digite para pesquisar a tarefa' 
                value={searchTerm} 
                onChange={(e) => onSearchChange(e.target.value)}
              />
            </label>
          </form>
          <button type="button" className='CRUDOptions' onClick={onAddClick}>
            +
          </button>
        </div> 
        <FilterBox
          selectedStatus={selectedStatus}
          onStatusChange={onStatusChange}
        />
      </div>
    </div>
  );
};

export default BarraDePesquisa;