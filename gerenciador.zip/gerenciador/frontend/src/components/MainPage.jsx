import React, { useState } from 'react';
import BarraDePesquisa from './BarraDePesquisa';
import ListaDeTarefas from './ListaDeTarefas';
import JanelaFlutuante from './JanelaFlutuante';
import FormAddTask from './FormAddTask';
import Header from './Header';
const initialTasks = [
    { id: 1, name: 'Modelar o banco de dados da aplicação', status: 'Em Progresso' },
    { id: 2, name: 'Criar o componente da barra de pesquisa', status: 'Concluído' },
];

function MainPage() {
  const [tasks, setTasks] = useState(initialTasks);
  const [isJanelaFlutuanteOpen, setIsJanelaFlutuanteOpen] = useState(false);

  const handleAddTask = (newTask) => {
    setTasks(prevTasks => [
      ...prevTasks,
      { 
        id: Date.now(), 
        ...newTask 
      }
    ]);
    setIsJanelaFlutuanteOpen(false);
  };

  const openJanelaFlutuante = () => setIsJanelaFlutuanteOpen(true);

  return (
    <div className="App">
      <Header/>
      
      <BarraDePesquisa onAddClick={openJanelaFlutuante} />
      
      <ListaDeTarefas tasks={tasks} />

      <JanelaFlutuante isOpen={isJanelaFlutuanteOpen} onClose={() => setIsJanelaFlutuanteOpen(false)}>
        <FormAddTask 
          onAddTask={handleAddTask}
          onCancel={() => setIsJanelaFlutuanteOpen(false)}
        />
      </JanelaFlutuante>
    </div>
  );
}

export default MainPage;