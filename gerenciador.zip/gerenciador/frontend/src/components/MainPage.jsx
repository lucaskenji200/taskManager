import React, { useState, useEffect, useMemo, useCallback } from 'react';
import BarraDePesquisa from './BarraDePesquisa';
import ListaDeTarefas from './ListaDeTarefas';
import JanelaFlutuante from './JanelaFlutuante';
import FormTask from './FormTask'; 
import Header from './Header';

function MainPage() {
  const [tasks, setTasks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('Todos');

  const API_URL = 'http://localhost:5000/api/tasks';

  const fetchTasks = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(API_URL);
      if (!response.ok) throw new Error('Falha ao buscar dados do servidor');
      const data = await response.json();
      setTasks(data.data || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  const handleOpenModalForNew = () => {
    setEditingTask(null);
    setIsModalOpen(true);
  };

  const handleOpenModalForEdit = (task) => {
    setEditingTask(task);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingTask(null);
  };

  const handleTaskSubmit = (updatedTask) => {
    if (editingTask) {
      setTasks(tasks.map(t => t.id === updatedTask.id ? updatedTask : t));
    } else {
      setTasks([...tasks, updatedTask]);
    }
  };

  const handleDeleteTask = async (taskId) => {
    if (!window.confirm("Tem certeza que deseja excluir esta tarefa?")) return;

    try {
      const response = await fetch(`${API_URL}/${taskId}`, { method: 'DELETE' });
      if (!response.ok) throw new Error('Falha ao deletar a tarefa.');
      setTasks(tasks.filter(t => t.id !== taskId));
    } catch (err) {
      alert(err.message);
    }
  };

  const filteredTasks = useMemo(() => {
    return tasks.filter(task => 
      (filterStatus === 'Todos' || task.status === filterStatus) &&
      task.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [tasks, searchTerm, filterStatus]);

  return (
    <div className="App">
      <Header />
      <BarraDePesquisa 
        onAddClick={handleOpenModalForNew}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        selectedStatus={filterStatus}
        onStatusChange={setFilterStatus}
      />
      
      {isLoading && <p>Carregando tarefas...</p>}
      {error && <p className="error">{error}</p>}
      {!isLoading && !error && (
        <ListaDeTarefas 
          tasks={filteredTasks} 
          onDelete={handleDeleteTask}
          onEdit={handleOpenModalForEdit}
        />
      )}

      <JanelaFlutuante isOpen={isModalOpen} onClose={handleCloseModal}>
        <FormTask
          onTaskSubmit={handleTaskSubmit}
          onCancel={handleCloseModal}
          taskToEdit={editingTask}
          apiUrl={API_URL}
        />
      </JanelaFlutuante>
    </div>
  );
}

export default MainPage;