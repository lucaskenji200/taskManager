import React from 'react';
import './Tarefa.css';

const Tarefa = ({ task, onDelete, onEdit }) => {
  const statusClass = {
    'Não Iniciado': 'status-not-started',
    'Em Andamento': 'status-in-progress',
    'Concluído': 'status-completed',
  };

  return (
    <li className="task-item">
      <div className="task-info">
        <h3>{task.name}</h3>
        <p>{task.description}</p>
      </div>
      <div className="task-meta">
        <span className={`task-status ${statusClass[task.status] || ''}`}>{task.status}</span>
        <div className="task-actions">
          <button onClick={() => onEdit(task)} className="edit-btn">Editar</button>
          <button onClick={() => onDelete(task.id)} className="delete-btn">Excluir</button>
        </div>
      </div>
    </li>
  );
};

export default Tarefa;