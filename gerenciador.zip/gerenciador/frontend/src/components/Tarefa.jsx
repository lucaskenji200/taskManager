import React from 'react';
const Tarefa = ({ task }) => {
  const statusClass = `status-${task.status.toLowerCase().replace(' ', '-')}`;
  
  const handleEdit = () => {
    console.log(`Editando a tarefa: ${task.name}`);
  };

  const handleDelete = () => {
    console.log(`Excluindo a tarefa: ${task.name}`);
  };

  return (
    <li className={`task-item ${statusClass}`}>
      <div className="task-info">
        <span className="task-title">{task.name}</span>
      </div>
      <div className="task-actions">
        <button onClick={handleEdit} className="action-btn edit-btn">Editar</button>
        <button onClick={handleDelete} className="action-btn delete-btn">Excluir</button>
      </div>
    </li>
  );
};

export default Tarefa;