import './Header.css'
import logo from '../assets/logo.png' 
const Header = () => {
  return (
    <div>
        <div className='c1'>
            <img src={logo} alt='Logo' className='logo_img'/>
            <h1 className='title'>Gerenciador de projetos</h1>
        </div>
    </div>
  )
}

export default Header