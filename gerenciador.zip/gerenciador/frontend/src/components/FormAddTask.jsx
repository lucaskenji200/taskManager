import React, { useState } from 'react';
import './FormAddTask.css';

const postTask = async ({ name, status }) => {
  const response = await fetch('http://localhost:5000/api/tasks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title: name, status }),
  });
  if (!response.ok) {
    throw new Error(`Erro ${response.status}: não foi possível criar a tarefa`);
  }
  return response.json();
};

const FormAddTask = ({ onAddTask, onCancel }) => {
  const [taskName, setTaskName] = useState('');
  const [taskStatus, setTaskStatus] = useState('Não Iniciado');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!taskName.trim()) {
      alert('Por favor, digite o nome da tarefa.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const newTask = await postTask({ name: taskName.trim(), status: taskStatus });
      onAddTask(newTask);

      onCancel();
    } catch (err) {
      console.error(err);
      setError('Falha ao adicionar a tarefa. Tente novamente.');
    } finally {
      setLoading(false);
      setTaskName('');
      setTaskStatus('Não Iniciado');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="add-task-form">
      <h2>Adicionar Nova Tarefa</h2>

      {error && <p className="form-error">{error}</p>}

      <div className="form-group">
        <label htmlFor="task-name">Nome da Tarefa</label>
        <input
          id="task-name"
          type="text"
          value={taskName}
          onChange={(e) => setTaskName(e.target.value)}
          placeholder="Ex: Criar página de login"
          disabled={loading}
        />
      </div>

      <div className="form-group">
        <label htmlFor="task-status">Status</label>
        <select
          id="task-status"
          value={taskStatus}
          onChange={(e) => setTaskStatus(e.target.value)}
          disabled={loading}
        >
          <option value="Não Iniciado">Não Iniciado</option>
          <option value="Em Progresso">Em Progresso</option>
          <option value="Concluído">Concluído</option>
        </select>
      </div>

      <div className="form-actions">
        <button
          type="button"
          className="btn-cancel"
          onClick={onCancel}
          disabled={loading}
        >
          Cancelar
        </button>
        <button
          type="submit"
          className="btn-submit"
          disabled={loading}
        >
          {loading ? 'Adicionando...' : 'Adicionar Tarefa'}
        </button>
      </div>
    </form>
  );
};

export default FormAddTask;