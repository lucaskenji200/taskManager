import React, { useState, useEffect } from 'react';
import './FormTask.css';

function FormTask({ onTaskSubmit, onCancel, taskToEdit, apiUrl }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState('Não Iniciado');
  const [error, setError] = useState('');

  useEffect(() => {
    if (taskToEdit) {
      setName(taskToEdit.name);
      setDescription(taskToEdit.description || '');
      setStatus(taskToEdit.status);
    } else {
      setName('');
      setDescription('');
      setStatus('Não Iniciado');
    }
  }, [taskToEdit]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('O nome da tarefa é obrigatório.');
      return;
    }

    const taskData = { name, description, status };
    const isEditing = !!taskToEdit;
    const url = isEditing ? `${apiUrl}/${taskToEdit.id}` : apiUrl;
    const method = isEditing ? 'PUT' : 'POST';

    try {
      const response = await fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(taskData),
      });

      if (!response.ok) throw new Error(`Falha ao ${isEditing ? 'atualizar' : 'criar'} a tarefa.`);
      
      const result = await response.json();
      onTaskSubmit(result.data);
      onCancel(); 
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="form-task">
      <h2>{taskToEdit ? 'Editar Tarefa' : 'Adicionar Nova Tarefa'}</h2>
      {error && <p className="form-error">{error}</p>}
      
      <div className="form-group">
        <label htmlFor="name">Nome da Tarefa</label>
        <input
          id="name"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Ex: Fazer compras"
        />
      </div>
      
      <div className="form-group">
        <label htmlFor="description">Descrição (Opcional)</label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Ex: Comprar pão, leite e ovos"
        />
      </div>

      <div className="form-group">
        <label htmlFor="status">Status</label>
        <select id="status" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="Não Iniciado">Não Iniciado</option>
          <option value="Em Andamento">Em Andamento</option>
          <option value="Concluído">Concluído</option>
        </select>
      </div>

      <div className="form-actions">
        <button type="button" onClick={onCancel} className="btn-cancel">Cancelar</button>
        <button type="submit" className="btn-save">{taskToEdit ? 'Salvar Alterações' : 'Adicionar Tarefa'}</button>
      </div>
    </form>
  );
}

export default FormTask;