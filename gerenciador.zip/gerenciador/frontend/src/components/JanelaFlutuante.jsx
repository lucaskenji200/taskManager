import React from 'react';
import './JanelaFlutuante.css';

const JanelaFlutuante = ({ isOpen, onClose, children }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div className="janela-flutuante-backdrop" onClick={onClose}>
      <div className="janela-flutuante-content" onClick={(e) => e.stopPropagation()}>
        <button className="janela-flutuante-close-btn" onClick={onClose}>×</button>
        {children}
      </div>
    </div>
  );
};

export default JanelaFlutuante;