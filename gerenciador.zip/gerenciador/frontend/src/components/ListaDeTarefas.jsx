  import React, { useState, useEffect, useCallback } from 'react';
  import Tarefa from './Tarefa';
  import './ListaDeTarefas.css';

  const ListaDeTarefas = () => {
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const getTasks = useCallback(async () => {
      setLoading(true);
      setError(null);
      try {
        const res  = await fetch('http://localhost:5000/api/tasks');
        if (!res.ok) throw new Error(`Status ${res.status}`);
        const json = await res.json();
        
        setTasks(Array.isArray(json) ? json : json.tasks || []);
      } catch (err) {
        setError('Falha ao carregar tarefas.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    }, []);
    console.log(tasks)
    useEffect(() => {
      getTasks();
    }, [getTasks]);

    if (loading) return <p>Carregando tarefas…</p>;
    if (error)   return <p className="error">{error}</p>;

    return (
      <div className="task-list-container">
        <ul className="task-list">
          {tasks.map(task => (
            <Tarefa key={task.id} task={task} />
          ))}
        </ul>
      </div>
    );
  };

  export default ListaDeTarefas;