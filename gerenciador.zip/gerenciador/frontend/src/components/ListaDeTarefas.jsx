import React from 'react';
import Tarefa from './Tarefa';
import './ListaDeTarefas.css';

const ListaDeTarefas = ({ tasks, onDelete, onEdit }) => {
  if (tasks.length === 0) {
    return <p className="no-tasks-message">Nenhuma tarefa encontrada.</p>;
  }

  return (
    <div className="task-list-container">
      <ul className="task-list">
        {tasks.map(task => (
          <Tarefa 
            key={task.id} 
            task={task} 
            onDelete={onDelete}
            onEdit={onEdit}
          />
        ))}
      </ul>
    </div>
  );
};

export default ListaDeTarefas;