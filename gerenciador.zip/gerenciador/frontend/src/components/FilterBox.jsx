import React from 'react';
import './FilterBox.css';

const FilterBox = ({selectedStatus, onStatusChange, searchTerm, onSearchChange}) => {
  return (
    <div className="filter-box-container">
      <div className="filter-group">
        <label htmlFor="status-filter">Status:</label>
        <select 
          id="status-filter"
          className="filter-select"
          value={selectedStatus}
          onChange={(e) => onStatusChange(e.target.value)}
        >
          <option value="Todos">Todos</option>
          <option value="Não Iniciado">Não Iniciado</option>
          <option value="Em Progresso">Em Progresso</option>
          <option value="Concluído">Concluído</option>
        </select>
      </div>
    </div>
  );
};

export default FilterBox;