import React from 'react';
import './FilterBox.css';

const FilterBox = ({selectedStatus, onStatusChange}) => {
  return (
    <div className="filter-box-container">
      <div className="filter-group">
        <label htmlFor="status-filter">Status:</label>
        <select 
          id="status-filter"
          className="filter-select"
          value={selectedStatus}
          onChange={(e) => onStatusChange(e.target.value)}
        >
          <option value="Todos">Todos</option>
          <option value="Não Iniciado">Não Iniciado</option>
          <option value="Em Andamento">Em Andamento</option>
          <option value="Concluído">Concluído</option>
        </select>
      </div>
    </div>
  );
};

export default FilterBox;